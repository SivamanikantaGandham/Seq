sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], function (Controller, JSONModel, MessageBox) {
    "use strict";

    return Controller.extend("totalenergies.sma.suppliercontact.controller.BaseController", {

        onInit: function () {
            this.oRouter = this.getOwnerComponent().getRouter();
        },

        getModel: function (sType, sName, sPath) {
            switch (sType) {
                case "core":
                    return sap.ui.getCore().getModel(sName);
                case "view":
                    return this.getView().getModel(sName);
                case "i18n":
                    return this.getOwnerComponent().getModel("i18n").getResourceBundle();
                case "local":
                    var oModel = new JSONModel();
                    return oModel.loadData(sPath, sName);
                default:
                    return this.getView().byId(sType).getModel(sName);
            }
        },

        getControl: function (id) {
            return this.getView().byId(id);
        },

        setModel: function (sType, oModel, sName) {
            switch (sType) {
                case "view":
                    return this.getView().setModel(oModel, sName);
                case "core":
                    return sap.ui.getCore().setModel(oModel, sName);
                default:
                    return this.getView().byId(sType).setModel(oModel, sName);
            }
        },

        onNavBack: function (sRouteName) {
            var sPreviousHash = sap.ui.core.routing.History.getInstance().getPreviousHash();
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

            if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
                history.go(-1);
            } else {
                this.oRouter.navTo(sRouteName, {}, true);
            }
        },

        _showErrorMessage: function (sKey) {
            var oBundle = this.getView().getModel("i18n").getResourceBundle();
            var sTitle = oBundle.getText("errorTitle");
            var sMessage = oBundle.getText(sKey);

            MessageBox.error(sMessage, {
                title: sTitle,
                actions: [MessageBox.Action.CLOSE]
            });
        }

    });
});
