sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"totalenergies/sma/suppliercontact/controller/BaseController"
], function (Controller, Filter, FilterOperator, MessageBox, BaseController) {
	"use strict";

	return BaseController.extend("totalenergies.sma.suppliercontact.controller.SupplierContactHome", {
		/**
		 * Called when the controller is instantiated.
		 * Sets up the initial JSON model for the view.
		 * Inherits initialization from BaseController.
		 * 
		 * @public
		 */
		onInit: function () {
			// Call the base controller's onInit method if needed
			BaseController.prototype.onInit.apply(this, arguments);

			var oMainModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oMainModel, "MainModel");
		},
		/**
		 * Handles the search event for supplier contact details.
		 * Validates the input BP Contact ID and retrieves the supplier contact data.
		 * Displays an error message if the BP Contact ID is not found or invalid.
		 * 
		 * @public
		 */
		onSearch: function () {
			var oView = this.getView();
			var sSupplierContactBP = oView.byId("suppliercontactBPInput").getValue();

			if (!sSupplierContactBP) {
				this._showErrorMessage("errorBPContactID");
				return;
			}

			// Call _fetchSupplierContactData with success and error callbacks
			this._fetchSupplierContactData(sSupplierContactBP, function (oData) {
				// Success callback
				if (oData) {
					// Make the form elements visible
					oView.byId("ScontactDetails").setVisible(true);
					oView.byId("FnameFormElement").setVisible(true);
					oView.byId("LnameFormElement").setVisible(true);
					oView.byId("PositionFormElement").setVisible(true);
					oView.byId("EmailFormElement").setVisible(true);
					oView.byId("PhoneFormElement").setVisible(true);
					oView.byId("submitButton").setVisible(true);
					oView.byId("suppliercontactBPInput").setEnabled(false);

					// Bind the data to the model
					var oModel = oView.getModel("MainModel");
					oModel.setProperty("/Contact", {
						First_Name: oData.First_Name,
						Last_Name: oData.Last_Name,
						Position: oData.Position,
						Email: oData.Email,
						Phone_Number: oData.Phone_Number,
						Cell_Number: oData.Cell_Number,
						Fax_Number: oData.Fax_Number,
						BPContactId: oData.BPContactId
					});

					// Set fields as editable or not
					oView.byId("Fname").setEditable(true);
					oView.byId("Lname").setEditable(true);
					oView.byId("idPosition").setEditable(true);
					oView.byId("Phone").setEditable(true);
					oView.byId("Cellphone").setEditable(true);
					oView.byId("Fax").setEditable(true);
					oView.byId("submitButton").setEnabled(true);
				} else {
					this._showErrorMessage("noDataFound");
				}
			}.bind(this), function (oError) {
				// Error callback
				this._showErrorMessage("errorBPContactID");
				oView.byId("suppliercontactBPInput").setEnabled(true);
				oView.byId("submitButton").setVisible(false);
			}.bind(this));
		},

		/**
		 * Fetches supplier contact data from the OData service using the provided BP Contact ID.
		 * 
		 * @param {string} sSupplierContactBP - The BP Contact ID to fetch the data for.
		 * @param {function} fnSuccess - The callback function to execute upon a successful data fetch.
		 * @param {function} fnError - The callback function to execute upon a data fetch error.
		 * 
		 * @private
		 */
		_fetchSupplierContactData: function (sSupplierContactBP, fnSuccess, fnError) {
			// Retrieve the OData model defined in manifest.json
			var oDataModel = this.getOwnerComponent().getModel();
			var sServicePath = "/supplierContactSet(BPContactId='" + sSupplierContactBP + "')";

			// Perform the OData read operation
			oDataModel.read(sServicePath, {
				success: function (oData) {
					// Call the success callback if provided
					if (fnSuccess) {
						fnSuccess(oData);
					}
				},
				error: function (oError) {
					// Call the error callback if provided
					if (fnError) {
						fnError(oError);
					}
				}
			});
		},

		/**
		 * Displays an error message using the MessageBox.
		 * 
		 * @param {string} sKey - The i18n key for the error message to display.
		 * 
		 * @private
		 */
		_showErrorMessage: function (sKey) {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var sTitle = oBundle.getText("errorTitle");
			var sMessage = oBundle.getText(sKey);

			sap.m.MessageBox.show(sMessage, {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: sTitle,
				actions: [sap.m.MessageBox.Action.CLOSE]
			});
		},

		/**
		 * Handles the submission of changes made to the supplier contact details.
		 * Validates the input fields and submits the data to the OData service.
		 * Displays a confirmation popup before submitting.
		 * 
		 * @public
		 */

		onSubmitChanges: function () {
			var oView = this.getView();
			var sSupplierContactBP = oView.byId("suppliercontactBPInput").getValue();
			var oModel = oView.getModel("MainModel");
			var oContact = oModel.getProperty("/Contact");
			var bValid = true;

			// Check 1: Mandatory fields (First Name and Last Name)
			if (!oContact.First_Name || !oContact.Last_Name) {
				this._showErrorMessage("mandatoryFieldsMissing");
				return;
			}

			// Validate each field using the provided validation methods
			var oFnameField = oView.byId("Fname");
			var oLnameField = oView.byId("Lname");
			var oPositionField = oView.byId("idPosition");
			var oPhoneField = oView.byId("Phone");

			// Validate Fname, Lname, and Position using onCharactersControlOthers
			this.onCharactersControlOthers({
				getSource: function () {
					return oFnameField;
				}
			});
			this.onCharactersControlOthers({
				getSource: function () {
					return oLnameField;
				}
			});
			this.onCharactersControlOthers({
				getSource: function () {
					return oPositionField;
				}
			});

			// Validate Phone using onCharactersControlPhone
			this.onCharactersControlPhone({
				getSource: function () {
					return oPhoneField;
				}
			});

			// Check if any of the fields are in an error state
			if (oFnameField.getValueState() === "Error" ||
				oLnameField.getValueState() === "Error" ||
				oPositionField.getValueState() === "Error" ||
				oPhoneField.getValueState() === "Error") {
				bValid = false;
			}

			// If validation failed, stop submission
			if (!bValid) {
				this._showErrorMessage("validationFailed");
				return;
			}

			// Confirmation popup
			sap.m.MessageBox.confirm(
				this.getView().getModel("i18n").getResourceBundle().getText("confirmChanges"), {
					title: this.getView().getModel("i18n").getResourceBundle().getText("confirmation"),
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (sAction) {
						if (sAction === sap.m.MessageBox.Action.YES) {
							// Perform PUT call
							var oDataModel = this.getView().getModel();
							var sPath = "/supplierContactSet(BPContactId='" + sSupplierContactBP + "')";
							oDataModel.update(sPath, oContact, {
								success: function () {
									sap.m.MessageBox.success(
										this.getView().getModel("i18n").getResourceBundle().getText("changesSuccess")
									);

									// Get the view and set the elements' visibility to false
									var oView = this.getView();
									oView.byId("ScontactDetails").setVisible(false);
									oView.byId("FnameFormElement").setVisible(false);
									oView.byId("LnameFormElement").setVisible(false);
									oView.byId("PositionFormElement").setVisible(false);
									oView.byId("EmailFormElement").setVisible(false);
									oView.byId("PhoneFormElement").setVisible(false);
									oView.byId("submitButton").setVisible(false);

									// Set form fields to non-editable
									oView.byId("Fname").setEditable(false);
									oView.byId("Lname").setEditable(false);
									oView.byId("idPosition").setEditable(false);
									oView.byId("Phone").setEditable(false);
									oView.byId("Cellphone").setEditable(false);
									oView.byId("Fax").setEditable(false);

									// Disable the submit button
									oView.byId("submitButton").setEnabled(false);

									// Optionally, you may want to enable the supplier contact input field again
									oView.byId("suppliercontactBPInput").setEnabled(true).setValue("");
								}.bind(this),
								error: function () {
									this._showErrorMessage("updateFailed");
								}.bind(this)
							});
						}
					}.bind(this)
				}
			);
		},

		/**
		 * Validates input fields for characters not allowed in certain fields (First Name, Last Name, Position).
		 * Displays an error message if invalid characters are found.
		 * 
		 * @param {sap.ui.base.Event} oEvent - The event object from the input field.
		 * 
		 * @public
		 */

		onCharactersControlOthers: function (oEvent) {
			var oFieldValue = oEvent.getSource().getValue();
			var pattern = /([!/£$%^*()+={};/#:@~,/<>?+"”\]\[&])+/g;
			var found = pattern.test(oFieldValue);

			if (found) {
				// Show message toast instead of setting value state text
				sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("errorPopUp1"), {
					duration: 3000, // Duration in milliseconds
					autoClose: true
				});

				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
			}
		},

		/**
		 * Validates input fields for characters not allowed in phone number fields.
		 * Displays an error message if invalid characters are found.
		 * 
		 * @param {sap.ui.base.Event} oEvent - The event object from the input field.
		 * 
		 * @public
		 */

		onCharactersControlPhone: function (oEvent) {
			var oFieldValue = oEvent.getSource().getValue();
			// Pattern to match any character that is not a digit or '+'
			var pattern = /[^0-9+]/g;
			var found = pattern.test(oFieldValue);

			if (found) {
				sap.m.MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("errorCharactersControlPhone"), {
					duration: 3000, // Duration in milliseconds
					autoClose: true
				});

				oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
			} else {
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
			}
		}

	});
});