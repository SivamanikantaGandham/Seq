sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"totalenergies/sma/suppliercontact/model/models",
	"sap/ui/model/resource/ResourceModel"
], function (UIComponent, Device, models, ResourceModel) {
	"use strict";

	return UIComponent.extend("totalenergies.sma.suppliercontact.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// set i18n model
			var i18nModel = new ResourceModel({
				bundleName: "totalenergies.sma.suppliercontact.i18n.i18n"  // Adjust the path to your i18n files
			});
			this.setModel(i18nModel, "i18n");
		}
	});
});
