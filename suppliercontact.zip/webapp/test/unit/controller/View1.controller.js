/*global QUnit*/

sap.ui.define([
	"totalenergies/sma/suppliercontact/controller/SupplierContactHome.controller"
], function (Controller) {
	"use strict";

	QUnit.module("SupplierContactHome Controller");

	QUnit.test("I should test the SupplierContactHome controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});