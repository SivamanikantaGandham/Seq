sap.ui.define([
	"totalenergies/sma/suppliercontact/test/unit/controller/SupplierContactHome.controller"
], function () {
	"use strict";
});